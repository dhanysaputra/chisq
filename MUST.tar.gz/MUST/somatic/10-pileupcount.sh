#!/bin/bash -l

module load bioinfo-tools
module load python/2.7.6

python /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/pileup_count.py \
-m -i $1.pileup \
-o $1.snvcount.txt
