#!/bin/bash -l

module load bioinfo-tools
module load GATK
module load samtools/0.1.18

date
echo "BaseRecalibrator...."

java -XX:+UseParallelGC -XX:ParallelGCThreads=8 -Xmx4g -jar /sw/apps/bioinfo/GATK/2.3.6/GenomeAnalysisTK.jar \
-T BaseRecalibrator \
-nct 8 \
-R /lynx/cvol/v25/b2012036/private/refGen/ucsc.hg19.fasta \
-knownSites /lynx/cvol/v25/b2012036/private/vcftools/vcfRef/dbsnp_137.hg19.vcf \
-o $1.recal_data.grp \
-I $1.real.bam \
date

