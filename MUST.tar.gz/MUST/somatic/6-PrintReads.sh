#!/bin/bash -l

module load bioinfo-tools
module load GATK
module load samtools/0.1.18

date
echo "PrintReads...."

java -XX:+UseParallelGC -XX:ParallelGCThreads=8 -jar /sw/apps/bioinfo/GATK/2.3.6/GenomeAnalysisTK.jar \
-T PrintReads \
-R /lynx/cvol/v25/b2012036/private/refGen/ucsc.hg19.fasta \
-nct 8 \
-I $1.real.bam \
-BQSR $1.recal_data.grp \
-o $1.recal.bam
date

