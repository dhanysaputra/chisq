#!/usr/bin/python

# python pileup_count.py sample.mpileup > sample.counts

import sys
import pdb
import re
import argparse

parser = argparse.ArgumentParser(description='Process mpileup files. Version: 11 Oct 2013.')

parser.add_argument('-i','--input',dest='input',type=open,
                    required=True,metavar='file',help='Input mpileup file.')
parser.add_argument('-o','--out', dest='output',type=argparse.FileType('w'),
                    default=sys.stdout,help="Output file",required=False)
parser.add_argument('-p','--phread',dest='offset',action='store',type=int,required=False,metavar='int',
                    default = 33,help='Specify phread offset [33].')
					
parser.add_argument('-m','--mqual',dest='mqual',action='store_true',help="Pileup contains map quality [False]")
parser.set_defaults(mqual=False)

args = parser.parse_args()

inFile = args.input.read().split("\n")
outFile = args.output
offset = args.offset
mqual = args.mqual

def qual_phred_from_ascii(letter):
        score = ord(letter) - offset
        return str(score)
        #return 10**(-1*score/10)

def writeData(st):
	if data[st] == "0":
		if mqual:
			outFile.write('\t'*16)
		else:
			outFile.write('\t'*12)
		st += 3
		return(st)
		
	coverage = data[st]
	bases = data[st+1].upper()
	hetero = 0
	types = {'A':0,'G':0,'C':0,'T':0,'-':0,'+':0,'X':[]}
	phred = data[st+2]
	phreds = {'A':[],'G':[],'C':[],'T':[]}
        
	if mqual:
		phred2 = data[st+3]
		phreds2 = {'A':[],'G':[],'C':[],'T':[]}

	i = 0
	k = 0
        
	while i < len(bases):
            base = bases[i]
            if(k < len(phred)):
                    base_ph = phred[k]
                    if mqual:
                            base_ph2 = phred2[k]
            if base == '^':
                    i += 1 ## skip the following ASCII character
            elif base == '$':
                    next # don't do anything.
            elif base == '-':
                    i += 1
                    m = prog.match(bases[i:])
                    addNum = int(m.group(0))
                    types['-'] += addNum
                    i += addNum + len(m.group(0)) - 1
            elif base == '*':
                    types['-'] += 1
            elif base == '+':
                    i += 1 ## move to the first digit
                    m = prog.match(bases[i:]) ## get the number after +
                    addNum = int(m.group(0)) ## turn it into a int
                    types['+'] += addNum ## add to '+'
                    i += addNum + len(m.group(0)) - 1 ## move i as many addNum plus length of digit - 1 (because i is already placed at the first digit position)
            elif base == '.' or base == ',':
                    types[ref] += 1
                    phreds[ref].append(qual_phred_from_ascii(base_ph))
                    if mqual:
                            phreds2[ref].append(qual_phred_from_ascii(base_ph2))
                    k += 1
            else:
                    if types.has_key(base):
                            types[base] += 1
                            hetero += 1
                            phreds[base].append(qual_phred_from_ascii(base_ph))
                            if mqual:
                                    phreds2[base].append(qual_phred_from_ascii(base_ph2))
                            k += 1
                    else:
                            types['X'].append(base)

            i += 1

    # adds = '.'
    # if len(types['+']) > 0:
    #         adds = ','.join(types['+'])

    # amb = '.'
    # if len(types['X']) > 0:
    #         amb = ','.join(types['X'])

	if(len(phreds['A']) != types['A']):
		raise NameError("'A' phred length not equal to 'A' counts")
	if(len(phreds['G']) != types['G']):
		raise NameError("'G' phred length not equal to 'G' counts")
	if(len(phreds['C']) != types['C']):
		raise NameError("'C' phred length not equal to 'C' counts")
	if(len(phreds['T']) != types['T']):
		raise NameError("'T' phred length not equal to 'T' counts")

	Aph = ";".join(phreds['A'])
	Tph = ";".join(phreds['T'])
	Cph = ";".join(phreds['C'])
	Gph = ";".join(phreds['G'])

	if mqual:
		Aph2 = ";".join(phreds2['A'])
		Tph2 = ";".join(phreds2['T'])
		Cph2 = ";".join(phreds2['C'])
		Gph2 = ";".join(phreds2['G'])

	if mqual:
		out = [types['A'],types['G'],types['C'],types['T'],types['-'],types['+'],hetero,coverage,Aph,Gph,Cph,Tph,Aph2,Gph2,Cph2,Tph2]
	else:
		out = [types['A'],types['G'],types['C'],types['T'],types['-'],types['+'],hetero,coverage,Aph,Gph,Cph,Tph]
	outFile.write('\t'.join([str(x) for x in out]))
	outFile.write("\t")
	st += nFields
	return(st)

prog = re.compile("[0-9]+")

#pdb.set_trace()

nFields = 3 ## default case
id = 0

for line in inFile:
		data = line.strip().split('\t')
		prevStar = False # keep track, within line, of sample with *

		if len(data) < 3:
			continue

        # Only first run        
		if id == 0:
			nCols = len(data) - 3
			if mqual:
				nFields = 4
			# if mqual and nCols%4:
				# raise NameError("mpileup file column number doesn't match argument -m")
			# if not mqual and nCols%3:
				# raise NameError("mpileup file column number without quality different from expected")
				
			nStar = 0
			for i in range(len(data)):
				nStar += data[i] == "*"
			
			if not nStar:
				nSamp = nCols/nFields
			else:
				nStar /= 2 # because a missing sample will have 2 *
				(nCols - nStar)/nFields
			
			outFile.write("chr\tbp\tref")
            
			#['%s_%s' % t for t in zip(a,["1"]*3)]
			
			cNames = ['A','G','C','T','del','ins','hetero','coverage','Aph','Gph','Cph','Tph','Aph2','Gph2','Cph2','Tph2']
			
			if mqual:
				cNames = ['A','G','C','T','del','ins','hetero','coverage','Aph','Gph','Cph','Tph','Aph2','Gph2','Cph2','Tph2']
				#cNames = "\tA\tG\tC\tT\tdel\tins\thetero\tcoverage\tAph\tGph\tCph\tTph\tAph2\tGph2\tCph2\tTph2"
			else:
				cNames = ['A','G','C','T','del','ins','hetero','coverage','Aph','Gph','Cph','Tph']
				#cNames = "\tA\tG\tC\tT\tdel\tins\thetero\tcoverage\tAph\tGph\tCph\tTph"

			for i in range(nSamp):
				outFile.write("\t")
				cNames_s = '\t'.join('%s_%s' % t for t in zip(cNames,[str(i+1)]*len(cNames)))		
				outFile.write(cNames_s)
			outFile.write("\n")
				
			id += 1

		chrm = data[0]
		bp = data[1]
		ref = data[2].upper()
		outFile.write('\t'.join([str(x) for x in [chrm,bp,ref]]))
		outFile.write('\t')

		st = 3
		for ns in range(nSamp):
			st = writeData(st)
		outFile.write("\n")

