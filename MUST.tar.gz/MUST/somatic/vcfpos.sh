#!/bin/bash -l

module load bioinfo-tools
module load samtools/0.1.18
module load python/2.6.6

date
awk -f /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/getsnv.awk $1.vcf | grep -v ^# | cut -f1,2 > $1_pos1.txt
python /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/addpos.py $1_pos1.txt > $1_pos.txt
date
samtools mpileup -f /lynx/cvol/v25/b2012036/private/refGen/human_g1k_v37.fasta -l $1_pos.txt -d 5000 -q 0 -Q 0 -s $2.bam $3.bam > TN.snv.pileup
date
python /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/pileup_count.sh -m -i TN.snv.pileup -o TN_snv_count.txt
rm -f $1_pos1.txt
date
