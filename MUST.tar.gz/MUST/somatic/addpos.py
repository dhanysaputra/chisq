#!/usr/bin/python

# python addpos.py inp.txt > out.txt

import sys
import pdb
import re

inFile = open(sys.argv[1],'r')




for line in inFile:
        data = line.strip().split('\t')
	chrm = data[0]
        start= int(data[1])-1
	end= int(data[1])

        
	out = [chrm,start, end]
        print '\t'.join([str(x) for x in out])

