#!/bin/bash -l

module load bioinfo-tools
module load samtools/0.1.18

date
echo "Step 2: Mark Duplicates....."
java -XX:+UseParallelGC -XX:ParallelGCThreads=8 -Xmx4g -jar /sw/apps/bioinfo/picard/1.41/MarkDuplicates.jar \
AS=true \
VALIDATION_STRINGENCY=LENIENT \
I=$1.sorted.bam  \
O=$1.markdup.bam \
M=$1.metrics \
REMOVE_DUPLICATES=true
date
echo "Step 2: Indexing $1.markdup.bam"
samtools index $1.markdup.bam
date
