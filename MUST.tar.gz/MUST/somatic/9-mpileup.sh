#!/bin/bash -l

module load bioinfo-tools
module load samtools/0.1.18

samtools mpileup -f /lynx/cvol/v25/b2012036/private/refGen/ucsc.hg19.fasta \
-l $1.pos.txt \
-d 5000 -q 0 -Q 0 -s $1.bam $2.bam > $1.pileup
