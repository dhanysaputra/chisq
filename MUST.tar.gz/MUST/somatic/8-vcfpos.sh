#!/bin/bash -l

module load bioinfo-tools
module load python/2.6.6

date
awk -f /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/getsnv.awk $1.vcf | grep -v ^# | cut -f1,2 > $1.pos1.txt
python /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/addpos.py $1.pos1.txt > $1.pos.txt
rm -f $1.pos1.txt
date
