#!/bin/bash -l

module load bioinfo-tools
module load GATK
module load samtools/0.1.18

date
echo "RealignerTargetCreator..."
java -XX:+UseParallelGC -XX:ParallelGCThreads=8 -Xmx2g -jar /sw/apps/bioinfo/GATK/2.3.6/GenomeAnalysisTK.jar \
-R /lynx/cvol/v25/b2012036/private/refGen/ucsc.hg19.fasta \
-T RealignerTargetCreator \
-nt 8 \
-known /lynx/cvol/v25/b2012036/private/vcftools/vcfRef/1000G_phase1.indels.hg19.vcf \
-o $1.intervals \
-I $1.markdup.bam
date

