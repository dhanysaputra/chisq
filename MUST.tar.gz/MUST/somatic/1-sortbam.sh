#!/bin/bash -l

module load bioinfo-tools
module load samtools/0.1.18

date
echo 'Step 1: Sorting...'
eval samtools sort $1.bam $1.sorted
date
echo 'Step 1: Indexing...'
eval samtools index $1.sorted.bam
date
