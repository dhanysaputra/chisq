#!/bin/bash -l

bam1=''
bam2=''
email=''
for ARG in $*
do
	if [[ $ARG == file1=* ]] && [[ $ARG == *.bam ]];
	then
		myparam=$( cut -d '=' -f 2- <<< "$ARG" | awk -F ".bam" '{print $1}' )
		bam1=$myparam
	elif [[ $ARG == file2=* ]] && [[ $ARG == *.bam ]];
        then
                myparam=$( cut -d '=' -f 2- <<< "$ARG" | awk -F ".bam" '{print $1}' )
                bam2=$myparam
	elif [[ $ARG == email=* ]];
        then
                myparam=$( cut -d '=' -f 2- <<< "$ARG" )
                email=$myparam
	fi
done
if [[ ${#bam1} ==  0 ]] || [[ ${#bam2} ==  0 ]];
then
	echo "Both BAM files needs to be mentioned"
fi
if [[ ${#email} ==  0 ]];
then
        echo "Write your email for job queueing status report"
fi
if [[ ${#bam1} != 0 ]] && [[ ${#bam2} != 0 ]];
then
	echo "1. Sorting & Indexing $bam1.bam and $bam2.bam"
	eval sbatch -A b2012036 -p core -n 1 -t 10:00:00 --mail-user=dhany.saputra@ki.se --mail-type=ALL -J Sorting /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/1-sortbam.sh $bam1 $email
	eval sbatch -A b2012036 -p core -n 1 -t 10:00:00 --mail-user=dhany.saputra@ki.se --mail-type=ALL -J Sorting2 /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/1-sortbam.sh $bam2 $email
	counter=0
	sleep 5
	while squeue -u dhany | grep -q 'Sorting'; do counter=`expr $counter + 5`; if [[ $(( $counter % 60 )) == 0 ]];then echo "BAM sorting-indexing time elapsed = $(( $counter / 60 )) min"; fi; sleep 5; done
	counter=`expr $counter + 5`;
	echo 'Time elapsed for sorting & indexing = $counter seconds'
	echo "2. Mark Duplicates"
	eval sbatch -A b2012036 -p core -n 8 -t 10:00:00 --mail-user=dhany.saputra@ki.se --mail-type=ALL -J Mark1 /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/2-markdup.sh $bam1
        eval sbatch -A b2012036 -p core -n 8 -t 10:00:00 --mail-user=dhany.saputra@ki.se --mail-type=ALL -J Mark2 /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/2-markdup.sh $bam2
	counter=0
        sleep 5
        while squeue -u dhany | grep -q 'Mark'; do counter=`expr $counter + 5`; if [[ $(( $counter % 60 )) == 0 ]];then echo "Mark Duplication time elapsed = $(( $counter / 60 )) min"; fi; sleep 5; done
        counter=`expr $counter + 5`;
        echo 'Time elapsed for mark duplication = $counter seconds'
	echo "2. Realigner Target Creator"
        eval sbatch -A b2012036 -p core -n 8 -t 10:00:00 --mail-user=dhany.saputra@ki.se --mail-type=ALL -J Real1 /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/3-RealignerTargetCreator.sh $bam1
        eval sbatch -A b2012036 -p core -n 8 -t 10:00:00 --mail-user=dhany.saputra@ki.se --mail-type=ALL -J Real2 /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/3-RealignerTargetCreator.sh $bam2
        counter=0
        sleep 5
        while squeue -u dhany | grep -q 'Real'; do counter=`expr $counter + 5`; if [[ $(( $counter % 60 )) == 0 ]];then echo "Realigner Target Creator time elapsed = $(( $counter / 60 )) min"; fi; sleep 5; done
        counter=`expr $counter + 5`;
        echo 'Time elapsed for realigner target creator = $counter seconds'
	echo "3. Indel Realigner"
        eval sbatch -A b2012036 -p core -n 1 -t 10:00:00 --mail-user=dhany.saputra@ki.se --mail-type=ALL -J Indel1 /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/4-IndelRealigner.sh $bam1 $email
        eval sbatch -A b2012036 -p core -n 1 -t 10:00:00 --mail-user=dhany.saputra@ki.se --mail-type=ALL -J Indel2 /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/4-IndelRealigner.sh $bam2 $email
        counter=0
        sleep 5
        while squeue -u dhany | grep -q 'Indel'; do counter=`expr $counter + 5`; if [[ $(( $counter % 60 )) == 0 ]];then echo "Indel Realigner time elapsed = $(( $counter / 60 )) min"; fi; sleep 5; done
        counter=`expr $counter + 5`;
        echo 'Time elapsed for indel realigner = $counter seconds'
	echo "5. Base Recalibrator"
        eval sbatch -A b2012036 -p core -n 1 -t 10:00:00 --mail-user=dhany.saputra@ki.se --mail-type=ALL -J Recal1 /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/5-BaseRecalibrator.sh $bam1 $email
        eval sbatch -A b2012036 -p core -n 1 -t 10:00:00 --mail-user=dhany.saputra@ki.se --mail-type=ALL -J Recal2 /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/5-BaseRecalibrator.sh $bam2 $email
        counter=0
        sleep 5
        while squeue -u dhany | grep -q 'Recal'; do counter=`expr $counter + 5`; if [[ $(( $counter % 60 )) == 0 ]];then echo "Base Recalibrator time elapsed = $(( $counter / 60 )) min"; fi; sleep 5; done
        counter=`expr $counter + 5`;
        echo 'Time elapsed for base recalibrator = $counter seconds'
	echo "6. Print Reads"
        eval sbatch -A b2012036 -p core -n 1 -t 10:00:00 --mail-user=dhany.saputra@ki.se --mail-type=ALL -J Read1 /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/6-PrintReads.sh $bam1 $email
        eval sbatch -A b2012036 -p core -n 1 -t 10:00:00 --mail-user=dhany.saputra@ki.se --mail-type=ALL -J Read2 /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/6-PrintReads.sh $bam2 $email
        counter=0
        sleep 5
        while squeue -u dhany | grep -q 'Read'; do counter=`expr $counter + 5`; if [[ $(( $counter % 60 )) == 0 ]];then echo "Print Read time elapsed = $(( $counter / 60 )) min"; fi; sleep 5; done
        counter=`expr $counter + 5`;
        echo 'Time elapsed for print read = $counter seconds'
	echo "7. Variant Calling: BCFTools"
	#echo "7. Variant Calling: Unified Genotyper"
	eval sbatch -A b2012036 -p core -n 1 -t 24:00:00 --mail-user=dhany.saputra@ki.se --mail-type=ALL -J bcf /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/7-bcftools.sh $bam1 $bam2
	counter=0
        sleep 5
        while squeue -u dhany | grep -q 'bcf'; do counter=`expr $counter + 5`; if [[ $(( $counter % 60 )) == 0 ]];then echo "Bcftools time elapsed = $(( $counter / 60 )) min"; fi; sleep 5; done
        counter=`expr $counter + 5`;
        echo "Time elapsed for variant calling = $counter seconds"
	echo "8. Extract SNV positions"
	date
	bash /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/8-vcfpos.sh $bam1
	date
	echo "9. mpileup count"
	eval sbatch -A b2012036 -p core -n 1 -t 12:00:00 --mail-user=dhany.saputra@ki.se --mail-type=ALL -J mpileup /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/9-mpileup.sh $bam1 $bam2
        counter=0
        sleep 5
        while squeue -u dhany | grep -q 'mpileup'; do counter=`expr $counter + 5`; if [[ $(( $counter % 60 )) == 0 ]];then echo "Time elapsed = $(( $counter / 60 )) min"; fi; sleep 5; done
        counter=`expr $counter + 5`;
	date
	bash /proj/b2012036/INBOX/Dhany/SomaticCaller/somatic/10-pileupcount.sh $bam1
	date
	echo "Time elapsed for mpileup = $counter seconds"
	echo "6. Choose the best SNVs"
	bash chisq.sh file=$bam1.snvcount.txt minmq=30 minbq=0 pvalue=1e-20 n=15
fi
