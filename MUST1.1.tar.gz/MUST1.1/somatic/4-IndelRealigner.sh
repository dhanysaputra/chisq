#!/bin/bash -l

module load bioinfo-tools
module load GATK
module load samtools/0.1.18

date
echo "IndelRealigner..."
java -XX:+UseParallelGC -XX:ParallelGCThreads=8 -Xmx4g -jar /sw/apps/bioinfo/GATK/2.3.6/GenomeAnalysisTK.jar \
-R $2 \
-T IndelRealigner \
-I $1.markdup.bam \
-targetIntervals $1.intervals \
-known $3 \
-o $1.real.bam
date
