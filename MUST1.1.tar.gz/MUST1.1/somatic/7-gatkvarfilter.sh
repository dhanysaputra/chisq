#!/bin/bash -l

module load bioinfo-tools
module load GATK
module load samtools/0.1.18


java -XX:+UseParallelGC -XX:ParallelGCThreads=8 -Xmx4g -jar /sw/apps/bioinfo/GATK/2.3.6/GenomeAnalysisTK.jar \
-T VariantFiltration \
-R /lynx/cvol/v25/b2012036/private/refGen/ucsc.hg19.fasta \
-V $1.vcf  \
-o $1.filtered.vcf \
--filterExpression "QD<2.0" \
--filterName QDfilter \
--filterExpression "MQ<40.0" \
--filterName MQfilter \
--filterExpression "FS>60.0" \
--filterName FSfilter \
--filterExpression "HaplotypeScore>13.0" \
--filterName HSfilter \
--filterExpression "MQRankSum<-12.5" \
--filterName MQRSfilter \
--filterExpression "ReadPosRankSum<-8.0" \
--filterName RPRSfilter
