#!/bin/bash -l

module load bioinfo-tools
module load GATK
module load samtools/0.1.18

date
echo "RealignerTargetCreator..."
java -XX:+UseParallelGC -XX:ParallelGCThreads=8 -Xmx2g -jar /sw/apps/bioinfo/GATK/2.3.6/GenomeAnalysisTK.jar \
-R $2 \
-T RealignerTargetCreator \
-nt $4 \
-known $3 \
-o $1.intervals \
-I $1.markdup.bam
date

