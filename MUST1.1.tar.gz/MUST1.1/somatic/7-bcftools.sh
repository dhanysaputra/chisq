#!/bin/bash -l

module load bioinfo-tools
module load GATK
module load samtools/0.1.18

samtools mpileup -uf /lynx/cvol/v25/b2012036/private/refGen/ucsc.hg19.fasta $1.recal.bam $2.recal.bam | bcftools view -bvcg - > $1.bcf
bcftools view $1.bcf | vcfutils.pl varFilter > $1.vcf
