#!/bin/bash -l

module load bioinfo-tools
module load GATK
module load samtools/0.1.18

date
echo "BaseRecalibrator...."

java -XX:+UseParallelGC -XX:ParallelGCThreads=8 -Xmx4g -jar /sw/apps/bioinfo/GATK/2.3.6/GenomeAnalysisTK.jar \
-T BaseRecalibrator \
-nct $4 \
-R $2 \
-knownSites $3 \
-o $1.recal_data.grp \
-I $1.real.bam 
date

