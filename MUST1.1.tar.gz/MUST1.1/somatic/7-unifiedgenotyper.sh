#!/bin/bash -l
#SBATCH -A b2012036
#SBATCH -p node -n 2
#SBATCH -t 10:00:00
#SBATCH --mail-user=$4
#SBATCH --mail-type=ALL
#SBATCH -J UG.varcall

module load bioinfo-tools
module load GATK
module load samtools



java -Xmx4g -jar /sw/apps/bioinfo/GATK/2.3.6/GenomeAnalysisTK.jar \
-T UnifiedGenotyper \
-R /lynx/cvol/v25/b2012036/private/refGen/human_g1k_v37.fasta \
-I $1.bam \
-I $2.bam \
-o $3.vcf \
-glm BOTH
