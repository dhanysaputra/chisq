#!/bin/bash -l

#for ARG in $*
#do
#	if [[ $ARG == file1=* ]] && [[ $ARG == *.bam ]];
#	then
#		myparam=$( cut -d '=' -f 2- <<< "$ARG" | awk -F ".bam" '{print $1}' )
#		bam1=$myparam
#	elif [[ $ARG == file2=* ]] && [[ $ARG == *.bam ]];
#        then
#                myparam=$( cut -d '=' -f 2- <<< "$ARG" | awk -F ".bam" '{print $1}' )
#                bam2=$myparam
#	elif [[ $ARG == email=* ]];
#        then
#                myparam=$( cut -d '=' -f 2- <<< "$ARG" )
#                email=$myparam
#	fi
#done

source $1 

bam1=$(echo $filebam1 | awk -F ".bam" '{print $1}')
bam2=$(echo $filebam2 | awk -F ".bam" '{print $1}')
echo ""
echo "Input file= ${bam1}, ${bam2}, and $1"
echo ""
if [[ ${#bam1} != 0 ]] && [[ ${#bam2} != 0 ]];
then
	echo "1. Sorting & Indexing"
	eval sbatch -A $uppmaxproject -p core -n 1 -t 10:00:00 --mail-user=$email --mail-type=ALL -J Sort$i $(pwd)/somatic/1-sortbam.sh $bam1
	eval sbatch -A $uppmaxproject -p core -n 1 -t 10:00:00 --mail-user=$email --mail-type=ALL -J Sort$i $(pwd)/somatic/1-sortbam.sh $bam2
	counter=0
	sleep 5
	while squeue -u $uppmaxuser | grep -q 'Sort'; do counter=`expr $counter + 5`; if [[ $(( $counter % 60 )) == 0 ]];then echo "BAM sorting-indexing time elapsed = $(( $counter / 60 )) min"; fi; sleep 5; done
	counter=`expr $counter + 5`;
	echo "Time elapsed for sorting & indexing = $counter seconds"
	echo "2. Mark Duplicates"
	eval sbatch -A $uppmaxproject -p core -n $markdup -t 10:00:00 --mail-user=$email --mail-type=ALL -J Mark $(pwd)/somatic/2-markdup.sh $bam1
       	eval sbatch -A $uppmaxproject -p core -n $markdup -t 10:00:00 --mail-user=$email --mail-type=ALL -J Mark $(pwd)/somatic/2-markdup.sh $bam2
	counter=0
       	sleep 5
       	while squeue -u dhany | grep -q 'Mark'; do counter=`expr $counter + 5`; if [[ $(( $counter % 60 )) == 0 ]];then echo "Mark Duplication time elapsed = $(( $counter / 60 )) min"; fi; sleep 5; done
        counter=`expr $counter + 5`;
        echo "Time elapsed for mark duplication = $counter seconds"
	echo "3. Realigner Target Creator"
        eval sbatch -A $uppmaxproject -p core -n $realign -t 10:00:00 --mail-user=$email --mail-type=ALL -J Real $(pwd)/somatic/3-RealignerTargetCreator.sh $bam1 $ref $known $realign
        eval sbatch -A $uppmaxproject -p core -n $realign -t 10:00:00 --mail-user=$email --mail-type=ALL -J Real $(pwd)/somatic/3-RealignerTargetCreator.sh $bam2 $ref $known $realign
        counter=0
        sleep 5
        while squeue -u dhany | grep -q 'Real'; do counter=`expr $counter + 5`; if [[ $(( $counter % 60 )) == 0 ]];then echo "Realigner Target Creator time elapsed = $(( $counter / 60 )) min"; fi; sleep 5; done
        counter=`expr $counter + 5`;
        echo "Time elapsed for realigner target creator = $counter seconds"
	echo "3. Indel Realigner"
        eval sbatch -A $uppmaxproject -p core -n $indel -t 10:00:00 --mail-user=$email --mail-type=ALL -J Indel $(pwd)/somatic/4-IndelRealigner.sh $bam1 $ref $known
        eval sbatch -A $uppmaxproject -p core -n $indel -t 10:00:00 --mail-user=$email --mail-type=ALL -J Indel $(pwd)/somatic/4-IndelRealigner.sh $bam2 $ref $known
        counter=0
        sleep 5
        while squeue -u dhany | grep -q 'Indel'; do counter=`expr $counter + 5`; if [[ $(( $counter % 60 )) == 0 ]];then echo "Indel Realigner time elapsed = $(( $counter / 60 )) min"; fi; sleep 5; done
        counter=`expr $counter + 5`;
        echo "Time elapsed for indel realigner = $counter seconds"
	echo "5. Base Recalibrator"
        eval sbatch -A $uppmaxproject -p core -n $recal -t 10:00:00 --mail-user=$email --mail-type=ALL -J Recal1 $(pwd)/somatic/5-BaseRecalibrator.sh $bam1 $ref $dbsnp $recal
        eval sbatch -A $uppmaxproject -p core -n $recal -t 10:00:00 --mail-user=$email --mail-type=ALL -J Recal2 $(pwd)/somatic/5-BaseRecalibrator.sh $bam2 $ref $dbsnp $recal
        counter=0
        sleep 5
        while squeue -u dhany | grep -q 'Recal'; do counter=`expr $counter + 5`; if [[ $(( $counter % 60 )) == 0 ]];then echo "Base Recalibrator time elapsed = $(( $counter / 60 )) min"; fi; sleep 5; done
        counter=`expr $counter + 5`;
        echo "Time elapsed for base recalibrator = $counter seconds"
	echo "6. Print Reads"
        eval sbatch -A $uppmaxproject -p core -n $printread -t 10:00:00 --mail-user=$email --mail-type=ALL -J Read1 $(pwd)/somatic/6-PrintReads.sh $bam1 $ref $printread
        eval sbatch -A $uppmaxproject -p core -n $printread -t 10:00:00 --mail-user=$email --mail-type=ALL -J Read2 $(pwd)/somatic/6-PrintReads.sh $bam2 $ref $printread
        counter=0
        sleep 5
        while squeue -u dhany | grep -q 'Read'; do counter=`expr $counter + 5`; if [[ $(( $counter % 60 )) == 0 ]];then echo "Print Read time elapsed = $(( $counter / 60 )) min"; fi; sleep 5; done
        counter=`expr $counter + 5`;
       	echo "Time elapsed for print read = $counter seconds"
	echo "7. Variant Calling: BCFTools"
	#echo "7. Variant Calling: Unified Genotyper"
	eval sbatch -A $uppmaxproject -p core -n 1 -t 24:00:00 --mail-user=$email --mail-type=ALL -J bcf $(pwd)/somatic/7-bcftools.sh $bam1 $bam2
	counter=0
       	sleep 5
       	while squeue -u dhany | grep -q 'bcf'; do counter=`expr $counter + 5`; if [[ $(( $counter % 60 )) == 0 ]];then echo "Bcftools time elapsed = $(( $counter / 60 )) min"; fi; sleep 5; done
       	counter=`expr $counter + 5`;
       	echo "Time elapsed for variant calling = $counter seconds"
	echo "8. Extract SNV positions"
	date
	bash $(pwd)/somatic/8-vcfpos.sh $bam1
	date
	echo "9. mpileup count"
	eval sbatch -A $uppmaxproject -p core -n 1 -t 12:00:00 --mail-user=$email --mail-type=ALL -J mpileup $(pwd)/somatic/9-mpileup.sh $bam1 $bam2
       	counter=0
       	sleep 5
       	while squeue -u dhany | grep -q 'mpileup'; do counter=`expr $counter + 5`; if [[ $(( $counter % 60 )) == 0 ]];then echo "Time elapsed = $(( $counter / 60 )) min"; fi; sleep 5; done
       	counter=`expr $counter + 5`;
	date
	bash $(pwd)/somatic/10-pileupcount.sh $bam1
	date
	echo "Time elapsed for mpileup = $counter seconds"
	echo "6. Choose the best SNVs"
	bash chisq.sh file=$bam1.snvcount.txt minmq=$minmq minbq=$minbq pvalue=$n n=$n
fi
